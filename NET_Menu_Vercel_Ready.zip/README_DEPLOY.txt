NET CAFFE & RESTAURANT - VERCEL READY
=====================================

EASIEST WAY: VERCEL DROP
1. Optionally add your own food photos to the images folder.
2. Edit index.html using VS Code. Ctrl+F -> PASTE FOOD IMAGE HERE.
3. Put the correct img: "images/your-photo.jpg" path for each dish.
4. Re-ZIP the contents of this folder (NOT a wrapping parent folder).
   The ZIP must contain index.html at the top level.
5. Open https://vercel.com/drop and log in.
6. Drag the ZIP file onto the page, choose a name, and Deploy.
7. Open your resulting https://your-project.vercel.app address.

IMPORTANT
- index.html must be in the root; do not rename it to menu.html.
- The images/ folder must be in the root beside index.html.
- Image names are case-sensitive (kebab.jpg differs from Kebab.JPG).
- Do not upload the example QA photos; use your real food photos.
- This is a static web menu. The order basket shows an order to the waiter;
  it does NOT send orders to the restaurant or store them on a server.
- Vercel Drop creates a new project for each upload. For updates to the
  same project, link Git or use Vercel CLI.

GIT/CLI ALTERNATIVE
In the project folder, run: npm i -g vercel; vercel --prod
Choose Framework Preset: Other. No install or build command required.

Menu file: index.html
Vercel settings: vercel.json
Restaurant images: images/
